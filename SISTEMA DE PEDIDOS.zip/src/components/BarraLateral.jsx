import React from 'react';
import { LayoutDashboard, ShoppingCart, Package, Users, FileText, Repeat, LogOut } from 'lucide-react';

const BarraLateral = ({ usuario, abaAtiva, setAbaAtiva, onLogout }) => {
  // Menu de navegação protegido contra erro de 'cargo'
  const menuItens = [
    { id: 'atendimento', label: 'Atendimento', icon: LayoutDashboard, roles: ['comercial', 'adm', 'master'] },
    { id: 'pedidos', label: 'Fazer Pedidos', icon: ShoppingCart, roles: ['comercial', 'adm', 'master'] },
    { id: 'transferencia', label: 'Transferência', icon: Repeat, roles: ['comercial', 'adm', 'master'] },
    { id: 'relatorios', label: 'Relatórios', icon: FileText, roles: ['adm', 'master'] },
    { id: 'gestao', label: 'Gestão', icon: Users, roles: ['adm', 'master'] },
    { id: 'estoque', label: 'Estoque', icon: Package, roles: ['adm', 'master'] },
  ];

  // Filtra os itens baseado no cargo do usuário (com proteção para undefined)
  const itensVisiveis = menuItens.filter(item => 
    item.roles.includes(usuario?.cargo?.toLowerCase() || 'comercial')
  );

  return (
    <aside className="w-72 bg-slate-900 flex flex-col border-r border-white/5 shadow-2xl">
      <div className="p-8">
        <h1 className="text-xl font-black text-white uppercase italic tracking-tighter">
          ERP <span className="text-blue-500">CDC</span>
        </h1>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {itensVisiveis.map((item) => {
          const Icone = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setAbaAtiva(item.id)}
              className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-xs uppercase transition-all ${
                abaAtiva === item.id 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                  : 'text-slate-500 hover:bg-white/5 hover:text-slate-300'
              }`}
            >
              <Icone size={20} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="p-6 border-t border-white/5">
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-xs uppercase text-red-400 hover:bg-red-500/10 transition-all"
        >
          <LogOut size={20} />
          Sair do Sistema
        </button>
      </div>
    </aside>
  );
};

export default BarraLateral;